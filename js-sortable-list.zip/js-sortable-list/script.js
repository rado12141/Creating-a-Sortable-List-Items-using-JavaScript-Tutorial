/** Selcect Sortable List Container */
const sortableList = document.querySelectorAll(".sortable-list-container ul")

/** Sorting Function */
const initSortableList = (e, listGroup) => {
   e.preventDefault()
    //List all list items of the list group
    var listItems = listGroup.querySelectorAll("li")

    // Current Item to transfer
    var currentDragging = listGroup.querySelector('li[data-dragging="true"]')

    // where mouse is pointing
    var currentPosition = e.clientY
    listItems.forEach(listItem=>{
        var rangeFrom = listItem.offsetTop;
        var rangeto = listItem.offsetTop + (listItem.clientHeight / 2);
        var rangeto2 = listItem.offsetTop + listItem.clientHeight;

        if(currentPosition > rangeFrom && currentPosition < rangeto){
            // Insert/Transfer Item before the Item if the mouse cursor is pointing at the upper area
            listGroup.insertBefore(currentDragging, listItem)
        }else if(currentPosition > rangeFrom && currentPosition < rangeto2){
            // Insert/Transfer Item after the Item if the mouse cursor is pointing at the lower area
            listItem.after(currentDragging)
        }
    })
}
sortableList.forEach(listGroup => {
    //Select All Draggable Enabled list items of the list group
    var listItems =  listGroup.querySelectorAll("li[draggable='true']")

    listItems.forEach(listItem=>{
        /** Event when drag started */
        listItem.addEventListener('dragstart', function(e){
            e.dataTransfer.effectAllowed = "move";
            setTimeout(()=>{
                listItem.dataset.dragging = "true"
            }, 10)
            
        })
        listItem.addEventListener('dragend', function(e){
            listItem.dataset.dragging = "false"
        })
    })
    listGroup.addEventListener('dragover', (e)=>{
        /** Initializing Sort */
        initSortableList(e, listGroup)
    })
})
